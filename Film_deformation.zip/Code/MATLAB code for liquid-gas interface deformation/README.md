## Liquid-gas interface deformation MATLAB code for the ultrafast bubble capturing on microconical aerophilic surfaces


# 1. Purpose

The repository contains the code needed to calculate the motion of bubbles of different sizes, the liquid-gas interface evolution and the film thinning rate on microconical aerophilic surfaces. All scripts are developed in MATLAB and are designed to be run in an environment where editing and running are easy.

# 2. Usage

There is a title model parameters in the main script 'main. m' and 'getInterfaceProfile. m' where the user can enter relevant information to run the script in the file, and the information needed to enter is:

- V0type = ""; % options are terminal or nonterminal,
- R = ; % bubble radius [mm]
- H10 = ; % initial top film thickness [mm]
- H200 = ; % initial distance from bubble top to interface [mm]

% Constants

- g = 9.81E-3; % gravitational acceleration [mm/ms^2]
- rhob = 1000E-9; % bottom liquid density [kg/mm^3]
- mub = 1E-9; % bottom liquid viscosity [kg/(mm*ms)] 
- sigmab = 72E-9; % bottom liquid surface tension [kg/ms^2] 
- rhot = 918E-9; % top liquid density [kg/mm^3] 

# 3. Output
 
Once this information has been provided, the script is ready to run and will calculate the entire process of the bubble ascent velocity, the liquid-gas interface evolution and the film thinning rate and output each calculated parameter.
