function [dydx,d2ydx2] = getDerivatives(y,dx)

% Function to get derivatives using second order finite difference
% scheme using central or backwards differences
% Assumes axisymmetric at y(1) which enables use of central difference
% scheme at this location for second derivatice

dydx = zeros(length(y),1);
d2ydx2 = zeros(length(y),1);
for i = 1:length(y)
    if i == 1
        dydx(i) = 0;
        d2ydx2(i) = (-2*y(i)+2*y(i+1))/dx^2; 
    elseif i == length(y)
        dydx(i) = (3/2*y(i)-2*y(i-1)+1/2*y(i-2))/dx;
        d2ydx2(i) = (2*y(i)-5*y(i-1)+4*y(i-2)-y(i-3))/dx^2;
    else
        dydx(i) = (-y(i-1)+y(i+1))/(2*dx);
        d2ydx2(i) = (y(i-1)-2*y(i)+y(i+1))/dx^2;

    end 
end
end