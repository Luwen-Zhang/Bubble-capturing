function [t,X,V,h,p,zS,zb,Fb,Fd,Fa,Ff] = getInterfaceProfile(tspan,maxstep,r,dr,R,rho,mu,sigma,g,H00,V0type)

% Solver for bubble collisions at a Gas-Liquid interface % Find terminal velocity if needed

if strcmpi(V0type,"terminal")
    Vtfun = @(V) 4/3*pi*R^3*rho*g-getLothCdRe(rho*abs(V)*2*R/mu,rho*V^2*2*R/sigma)*pi/4*mu*R*V;
    Vt = fzero(Vtfun,0.2); % terminal velocity
end

% Get coefficients for integration by Simpson's rule

SimpCoeff = getSimpCoeff(length(r));

% Initial Conditions

h0 = H00+r.^2/(2*R);
p0 = zeros(size(r));
zS0 = zeros(size(r));
X0 = H00+R;
if strcmpi(V0type,"terminal")
    V0 = Vt;
    Fa0 = 0;
elseif strcmpi(V0type,"nonterminal")
    V0 = 0;
    Fa0 = 4/3*pi*R^3*rho*g;
end
Ff0 = 0; Fd0 = getLothCdRe(rho*abs(V0)*2*R/mu,rho*V0^2*2*R/sigma)*pi/4*mu*R*V0;
y0 = [h0;p0;zS0;X0;V0;Ff0;Fd0;Fa0];

% Initial time derivatives

hp0 = -V0*ones(size(r));
pp0 = zeros(size(r));
zSp0 = zeros(size(r));
Xp0 = -V0;
if strcmpi(V0type,"terminal")
    Vp0 = 0;
elseif strcmpi(V0type,"nonterminal")
    Vp0 = 2*g;
end
Ffp0 = 0;
Fdp0 = 0;
Fap0 = 0; yp0 = [hp0;pp0;zSp0;Xp0;Vp0;Ffp0;Fdp0;Fap0]; % Set mass matrix
M = zeros(3*length(r)+5);
for j = 1:length(r)
    M(j,j) = 1; % dhdt
end
M(length(r),3*length(r)) = -1; % dhdt at r=rm
M(3*length(r)+1,3*length(r)+1) = 1; % dXdt 
M(3*length(r)+2,3*length(r)+2) = 1; % dVdt

% Set absolute tolerances - [unit] tolerance 

hAbsTol = 1E-6*ones(size(r)); % [mm] 1 nm 
pAbsTol = 1E-11*ones(size(r)); % [GPa] 10 mPa
zSAbsTol = 1E-6*ones(size(r)); % [mm] 1 nm 
XAbsTol = 1E-6; % [mm] 1 nm
VAbsTol = 1E-6; % [m/s] 1 um/s
FAbsTol = 1E-9*ones(3,1); % [kN] 1 uN 
AbsTol = [hAbsTol;pAbsTol;zSAbsTol;XAbsTol;VAbsTol;FAbsTol];

% Set options 

options = odeset('Mass',M,'InitialSlope',yp0,'MassSingular','yes','Events',@(t,y) eventfun(t,y,r),'Maxstep',maxstep,'AbsTol',AbsTol);
 
% Get consistent initial conditions if needed

implicitODE = @(t,y,yp) M*yp-fun(t,y,dr,R,r,rho,mu,sigma,g,SimpCoeff);
if sum(abs(implicitODE(tspan(1),y0,yp0))>AbsTol)>0
[y0_new,yp0_new] = decic(implicitODE,tspan(1),y0,[],yp0,[],options); y0=y0_new;
options = odeset(options,'InitialSlope',yp0_new);
end

% y is a system of ODEs s.t. 
% y=[h;p;zS;X;V;Ff;Fd;Fa]

[t,y] = ode15s(@(t,y) fun(t,y,dr,R,r,rho,mu,sigma,g,SimpCoeff),tspan,y0,options);
h = y(:,1:length(r)); % film thickness 
p = y(:,length(r)+1:2*length(r)); % film pressure 
zS = y(:,2*length(r)+1:3*length(r)); % interface shape 
zb = zS-h; % bubble surface shape 
X = y(:,3*length(r)+1); % bubble center trajectory 
V = y(:,3*length(r)+2); % bubble center velocity 
Ff = y(:,3*length(r)+3); % film force 
Fd = y(:,3*length(r)+4); % drag force 
Fa = y(:,3*length(r)+5); % added mass force 
Fb = -4/3*pi*R^3*rho*g*ones(size(t)); % buoyancy force

function f = fun(~,y,dr,R,r,rho,mu,sigma,g,SimpCoeff) 
    f = zeros(size(y));

% Temporary variables for easier calculations 

htemp = y(1:length(r)); 
ptemp = y(length(r)+1:2*length(r));
zStemp = y(2*length(r)+1:3*length(r)); 
Vtemp = y(3*length(r)+2);

% Get spatial derivatives, all second order
[dhdr,d2hdr2] = getDerivatives(htemp,dr); 
[dpdr,d2pdr2] = getDerivatives(ptemp,dr); 
[dzSdr,d2zSdr2] = getDerivatives(zStemp,dr);

% Get Cd and Cm 
CdRe = getLothCdRe(rho*abs(Vtemp)*2*R/mu,rho*Vtemp^2*2*R/sigma); Cm=0.5;
L = 2.5;%微结构宽度
if 1.2*R<1.25
        for i = 1:length(f)
        if i == 1 % dhdt at r = 0
            f(i) = 2*y(i)^3/(3*mu)*d2pdr2(i);
        elseif i>1 && i<length(r) % dhdt
        f(i) = y(i)^3/(3*mu*r(i))*dpdr(i)+y(i)^2/mu*dhdr(i)*dpdr(i)+y(i)^3/(3*mu)*d2pdr2(i);
        elseif i == length(r) % dhdt at r = rm
            f(i) = -Vtemp;
    elseif i == length(r)+1 % dpdt at r=0 
            f(i) = -y(i)+sigma/R+rho*g*zStemp(i-length(r))/2-sigma*d2hdr2(i-length(r));
    elseif i>length(r)+1 && i<2*length(r) % dpdt
             %f(i) = -y(i)+sigma/R+rho*g*zStemp(i-length(r))/2-sigma/(2*r(i-length(r)))*dhdr(i-length(r))-sigma/2*d2hdr2(i-length(r));
             f(i) = -y(i)+sigma/R-sigma/(2*r(i-length(r)))*dhdr(i-length(r))-sigma/2*d2hdr2(i-length(r));
        elseif i == 2*length(r) % dpdt at r = rm
            f(i) = y(i);
    elseif i == 2*length(r)+1 % dzdt at r = 0 
        f(i) = rho*g*y(i)-ptemp(i-2*length(r))-2*sigma*d2zSdr2(i-2*length(r));
        
    elseif i>2*length(r)+1 && i<3*length(r) % dzdt
        f(i) = rho*g*y(i)-ptemp(i-2*length(r))-sigma/r(i-2*length(r))*dzSdr(i-2*length(r))-sigma*d2zSdr2(i-2*length(r));
      elseif i == 3*length(r) % dzdt at r = rm 
        f(i) = y(i)-y(3*length(r)+3)/(2*pi*sigma)*besselk(0,r(end)/sqrt(sigma/(rho*g)))+y(3*length(r)+3)/(2*pi*sigma)*besselk(0,L/2/sqrt(sigma/(rho*g))); 
        elseif i == 3*length(r)+1 % dXdt
            f(i) = -Vtemp;
        elseif i == 3*length(r)+2 % dVdt
            f(i) = (4/3*pi*R^3*rho*g-CdRe*pi/4*mu*R*y(i)-2*pi*dr/3*sum(SimpCoeff.*r.*ptemp))/(4/3*pi*R^3*rho*Cm);
        elseif i == 3*length(r)+3 % dFfdt 
            f(i) = y(i)-2*pi*dr/3*sum(SimpCoeff.*r.*ptemp);
        elseif i == 3*length(r)+4 % dFddt
            f(i) = y(i)-CdRe*pi/4*mu*R*Vtemp;
        elseif i == 3*length(r)+5 % dFadt 
            f(i) = y(i)-4/3*pi*R^3*rho*Cm*f(3*length(r)+2);
        end 
        end
else
        for i = 1:length(f)     
        if i == 1 % dhdt at r = 0 
            f(i) = 2*y(i)^3/(3*mu)*d2pdr2(i);
        elseif i>1 && i<length(r) % dhdt
        f(i) = y(i)^3/(3*mu*r(i))*dpdr(i)+y(i)^2/mu*dhdr(i)*dpdr(i)+y(i)^3/(3*mu)*d2pdr2(i);
        elseif i == length(r) % dhdt at r = rm
            f(i) = -Vtemp;
    elseif i == length(r)+1 % dpdt at r = 0 
            f(i) = -y(i)+sigma/R+rho*g*zStemp(i-length(r))/2-sigma*d2hdr2(i-length(r));
            %f(i) = -y(i)+sigma/R-sigma*d2hdr2(i-length(r));
    elseif i>length(r)+1 && i<2*length(r) % dpdt
             f(i) = -y(i)+sigma/R+rho*g*zStemp(i-length(r))/2-sigma/(2*r(i-length(r)))*dhdr(i-length(r))-sigma/2*d2hdr2(i-length(r));
             %f(i) = -y(i)+sigma/R-sigma/(2*r(i-length(r)))*dhdr(i-length(r))-sigma/2*d2hdr2(i-length(r));
             
             
        elseif i == 2*length(r) % dpdt at r = rm
            f(i) = y(i);%
    elseif i == 2*length(r)+1 % dzdt at r = 0 
        f(i) = rho*g*y(i)-ptemp(i-2*length(r))-2*sigma*d2zSdr2(i-2*length(r));
    elseif i>2*length(r)+1 && i<2*length(r)+125 % dzdt
        f(i) = rho*g*y(i)-ptemp(i-2*length(r))-sigma/r(i-2*length(r))*dzSdr(i-2*length(r))-sigma*d2zSdr2(i-2*length(r));
      
        elseif i>=2*length(r)+125 && i<=3*length(r) % dzdt at r = rm 
        %f(i) = y(i)-y(3*length(r)+3)/(2*pi*sigma)*besselk(0,r(end)/sqrt(sigma/(rho*g))); 
        f(i) = y(i);%z = 0 when r = 1.25mm
        
        elseif i == 3*length(r)+1 % dXdt
            f(i) = -Vtemp;
        elseif i == 3*length(r)+2 % dVdt
            f(i) = (4/3*pi*R^3*rho*g-CdRe*pi/4*mu*R*y(i)-2*pi*dr/3*sum(SimpCoeff.*r.*ptemp))/(4/3*pi*R^3*rho*Cm);
        elseif i == 3*length(r)+3 % dFfdt 
            f(i) = y(i)-2*pi*dr/3*sum(SimpCoeff.*r.*ptemp);
        elseif i == 3*length(r)+4 % dFddt
            f(i) = y(i)-CdRe*pi/4*mu*R*Vtemp;
        elseif i == 3*length(r)+5 % dFadt 
            f(i) = y(i)-4/3*pi*R^3*rho*Cm*f(3*length(r)+2);
        end 
    end
end

end
function [value,isterminal,direction] = eventfun(~,y,r) % Stop solver if film thickness goes to zero 
    value = min(y(1:length(r)));
isterminal = 1;
    direction = 0;
end 
end