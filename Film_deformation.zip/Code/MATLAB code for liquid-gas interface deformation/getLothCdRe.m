
function CdRe = getLothCdRe(Re,We)

% Determines drag coefficient for a clean bubble based on Reynolds and % Weber number
% Based on Loth, 2008, Quasi-Steady Shape and Drag of
% Deformable Bubbles and Drops

if Re == 0
    CdRe = 0;
else
    f = 2/3+(12./Re+0.75*(1+3.315./sqrt(Re))).^-1; 
    CdWe0 = 24*f./Re;
    CdWeInf = 8/3+16./Re;
    if Re < 100
        Cd = tanh(0.021*We.^1.6).*(CdWeInf-CdWe0)+CdWe0;
    else
        if We < 3
            Emin = 0.25+0.55*exp(-0.09*Re); 
            cE = 0.165+0.55*exp(-0.3*Re); 
            E = 1-(1-Emin).*tanh(cE.*We);
            XLoth = 1./E;
            K = 0.0195*XLoth.^4-0.2134*XLoth.^3+1.7026*XLoth.^2-2.1461*XLoth-1.5732; 
            G = 1/3*XLoth.^(4/3).*(XLoth.^2-1).^1.5.*(sqrt(XLoth.^2-1)-(2-XLoth.^2).*asec(XLoth))./(XLoth.^2.*asec(XLoth)-sqrt(XLoth.^2-1)).^2; 
            Cd = 48./Re.*G.*(1+K./sqrt(Re));
        elseif We > 5 
            Cd = (2.5*tanh(0.2*We)-1.5).*(CdWeInf-CdWe0)+CdWe0;
        else
            Emin = 0.25+0.55*exp(-0.09*Re);
            cE = 0.165+0.55*exp(-0.3*Re); 
            E = 1-(1-Emin).*tanh(cE.*We);
            XLoth = 1./E; 
	    K = 0.0195*XLoth.^4-0.2134*XLoth.^3+1.7026*XLoth.^2-2.1461*XLoth-1.5732;
            G = 1/3*XLoth.^(4/3).*(XLoth.^2-1).^1.5.*(sqrt(XLoth.^2-1)-(2-XLoth.^2).*asec(XLoth))./(XLoth.^2.*asec(XLoth)-sqrt(XLoth.^2-1)).^2;
            CdMoore = 48./Re.*G.*(1+K./sqrt(Re));
            CdSep = (2.5*tanh(0.2*We)-1.5).*(CdWeInf-CdWe0)+CdWe0; 
            Cd = max(CdMoore,CdSep);
        end 
    end
    CdRe = Cd.*Re;
end