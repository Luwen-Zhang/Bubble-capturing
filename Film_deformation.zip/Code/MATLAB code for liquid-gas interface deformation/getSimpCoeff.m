function SimpCoeff = getSimpCoeff(n)
% Travis S. Emery
% Function to get coefficeints used for integration by Simpson's rule % Standard form only works for odd n, combine with Simpson's 3/8 rule % for even n
SimpCoeff = ones(n,1);
if mod(n,2) ~= 0
    for k = 2:n-1
        if mod(k,2) == 0
            SimpCoeff(k) = 4;
        else
            SimpCoeff(k) = 2;
        end 
    end
else
    for k = 2:n-4
        if mod(k,2) == 0
            SimpCoeff(k) = 4;
        else
            SimpCoeff(k) = 2;
        end
    end
    SimpCoeff(end-3) = 17/8;
    SimpCoeff(end-2) = 27/8;
    SimpCoeff(end-1) = 27/8;
    SimpCoeff(end) = 9/8;
end 
end