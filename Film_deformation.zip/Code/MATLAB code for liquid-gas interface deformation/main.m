% Bubble collision modeling with structure
% The main controlling function

tic
close all
clear
clc

% Model Parameters

Itype = "GL"; % gas-liquid interface
V0type = "terminal"; % options are terminal or nonterminal,
Cm = 0.46;
R = 1.4; % bubble radius [mm]
height_S = 0.6; % [mm]
spacing_S = 1;% [mm]


H10 = 0.5; % initial top film thickness [mm]
H200 = 10; % initial distance from bubble top to interface [mm]

% Constants

g = 9.81E-3; % gravitational acceleration [mm/ms^2]

% Liquid properties

rhob = 1000E-9; % bottom liquid density [kg/mm^3]

mub = 1E-9; % bottom liquid viscosity [kg/(mm*ms)] 
sigmab = 72E-9; % bottom liquid surface tension [kg/ms^2] 
rhot = 918E-9; % top liquid density [kg/mm^3] 

% Discretization

dr = 0.01; % spatial resolution [mm] 
rm = round(1.2*R/dr)*dr; % outer boundary location [mm] 
r = linspace(0,rm,rm/dr+1).'; % spatial domain
dt = 0.01; % time resolution [ms]
tf = 100; % final time [ms]
tspan = linspace(0,tf,tf/dt+1).'; % time domain 
maxstep = 0.01; % maximum time step for solver [ms]

% Solve the system described by the above parameters

[k,X,V,h,p,zS,zb,Fb,Fd,Fa,Ff] = getInterfaceProfile(tspan,maxstep,r,dr,R,rhob,mub,sigmab,g,H200,V0type);


% Convert solution to desired units and combine % [ms] [mm] [cm/s] [uN]

Sol = [k X V*100 Fb*-1E9 Fd*-1E9 Fa*-1E9 Ff*-1E9];
dhdt = zeros(size(h));
size = size(h);
for i = 1:size(1)-1
    for j = 1:size(2)
    dhdt(i,j) = (h(i,j)-h(i+1,j))/0.01;
    end
end
toc