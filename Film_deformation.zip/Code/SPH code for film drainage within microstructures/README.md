# SPH code for the ultrafast bubble capturing on simply microtextured aerophilic surfaces
## 1. Purpose
This is the fortran code for the two-phase MUSCL SPH method which is used to simulate ultrafast bubble capturing on simply microtextured aerophilic surfaces under various microstructure scales and bubble radius. 

## 2. Usage
###2.1 Install and build
The code is written with modern Fortran. Thus, a Fortran compiler is required. We recommend the intel oneapi HPC toolkit. On windows, the visual studio is used as the IDE. On linux, it can be compiled with make utility.

###2.2 Input and pre-processing
Users can customize their own physical parameters, geometry scales and time steps by searching the following varibles' names in corresponding files:
####For physical parameters:
```
varible_name			comments
rho0(1)			!reference density of water (..\subroutine\set parameter.f90)
rho0(2)			!reference density of air (..\subroutine\set parameter.f90)
gamma0(1)		!specific heat ratio of water (..\subroutine\set parameter.f90)
gamma0(2)		!specific heat ratio of air (..\subroutine\set parameter.f90)
c0(1)			!sound speed of water (..\subroutine\set parameter.f90)
c0(2)			!sound speed of air (..\subroutine\set parameter.f90), Note that this parameter should not be prescribed, because it depends on the rho0 and gamma0
water_pressure0		!initial pressure of water (..\module\input mod.f90)
bubble_pressure0		!initial pressure of air (..\module\input mod.f90)
SFsigma			!surface tension coefficient of pure water (..\module\module general parameter.f90)
ContactAngel		!advancing angle of the wall surface (..\module\module general parameter.f90)
gravity			!acceleration of gravity (..\module\module general parameter.f90)
```

####For geometry scales:
```
varible_name			comments
inboundary		!size of the water tank (..\subroutine\input SPH on my own.f90)
r0			!bubble radius (..\module\input mod.f90)
centerb			!coordinate of the bubble center (..\module\input mod.f90)
MS_L			!spacing of the microstructures (..\subroutine\CreateMicroStructure.f90)
MS_a			!width of a microstructure (..\subroutine\CreateMicroStructure.f90)
MS_b			!height of a microstructure (..\subroutine\CreateMicroStructure.f90)
```

####For  time steps:
```
t_des			!total physical time of simulation (..\subroutine\time integration.f90)
outputINT			!output interval by steps (..\subroutine\time integration.f90)
```

###2.3 Output and post-processing
The output file defaults to .vtp format formulated in file "..\subroutine\outputVTU.f90". Users are encouraged to open the output files in "Paraview", an open source software for visualization.
